"""
Pretty / useful exceptions.

Remember to set a value to the BETTER_EXCEPTIONS environment variable:
export BETTER_EXCEPTIONS=1
"""


def example():
    raise NotImplementedError("Error here!")


example()
