__name__ = "{{Name}}"
__version__ = "{{Version}}"
